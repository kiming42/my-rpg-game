/**
 * 萬用題庫資料庫 (src/data/questions.js)
 * 完整收錄 62 個字詞 ＋ 62 條字義解釋 ＋ 124 句情境例句填充 (共 186 種題目變化)
 */

 export const SubjectMeta = {
  chi: { id: 'chi', name: '📘 中文科', auraClass: 'aura-chi', lang: 'zh-HK' }
};

export const QuestionBank = [
  {"id": "chi_001", "unit": "成語一", "word": "人聲鼎沸", "meaning": "比喻人聲嘈雜，就像煮沸了水一樣。鼎，古代的煮食器具。", "missingFormat": "人聲鼎(？)", "options": ["沸", "破", "杳", "彎"], "answer": "沸", "sentence": "酒樓內（＿＿＿＿），坐滿了來吃午飯的人。", "sentence2": "大家都在為球隊吶喊助威，觀眾席上（＿＿＿＿）。"},
  {"id": "chi_002", "unit": "成語一", "word": "水泄不通", "meaning": "連一滴水也流不出去，形容包圍緊密，也形容環境極度擁擠。", "missingFormat": "水泄不(？)", "options": ["通", "雌", "棋", "緘"], "answer": "通", "sentence": "警方把這幢大廈封鎖得（＿＿＿＿），躲藏在內的匪徒難以逃脫。", "sentence2": "年三十晚，許多市民都會到年宵市場辦年貨，使場內擠得（＿＿＿＿）。"},
  {"id": "chi_003", "unit": "成語一", "word": "日積月累", "meaning": "指每天、每月地不斷積累。", "missingFormat": "日積月(？)", "options": ["累", "大", "布", "氣"], "answer": "累", "sentence": "趙女士憑藉（＿＿＿＿）的工作經驗，很快就替公司解決了這個難題。", "sentence2": "我每天都會學習英文新詞，經過（＿＿＿＿），現在認識的詞彙量已非常豐富了。"},
  {"id": "chi_004", "unit": "成語一", "word": "目不暇給", "meaning": "形容眼前有太多美好的事物，或景物變化太快，眼睛來不及觀看。", "missingFormat": "目不暇(？)", "options": ["給", "緻", "外", "聲"], "answer": "給", "sentence": "聯歡晚會的節目既豐富又精彩，令觀眾們（＿＿＿＿）。", "sentence2": "在空中綻放的煙花色彩繽紛，形態變化多端，令人（＿＿＿＿）。"},
  {"id": "chi_005", "unit": "成語一", "word": "世外桃源", "meaning": "與世隔絕、開滿桃花的樂土。比喻風景優美、人煙稀少的地方，亦比喻人們心目中的理想世界。", "missingFormat": "世外桃(？)", "options": ["源", "信", "目", "鼎"], "answer": "源", "sentence": "這裡四周鳥語花香，遠離鬧市，就像住在（＿＿＿＿）。", "sentence2": "這個城市沒遭受戰火波及，對大批流亡的難民來說就好比（＿＿＿＿）。"},
  {"id": "chi_006", "unit": "成語一", "word": "杳無人煙", "meaning": "形容地方偏僻荒涼，無人居住。杳，深遠。人煙，居民。", "missingFormat": "杳無人(？)", "options": ["煙", "角", "業", "外"], "answer": "煙", "sentence": "這個村落（＿＿＿＿），很多人已經從這兒搬到其他地方居住。", "sentence2": "政府正計劃將一些（＿＿＿＿）的地區開發成新市鎮，希望增加土地供應，推動城市發展。"},
  {"id": "chi_007", "unit": "成語一", "word": "風和日麗", "meaning": "形容天氣晴朗和暖，十分宜人。", "missingFormat": "風和日(？)", "options": ["麗", "規", "天", "彎"], "answer": "麗", "sentence": "今天是（＿＿＿＿）的好日子，我們一家人決定到郊野公園遊玩。", "sentence2": "天氣真是變幻莫測，早上還是（＿＿＿＿），傍晚卻颳起了狂風暴雨。"},
  {"id": "chi_008", "unit": "成語一", "word": "星羅棋布", "meaning": "如羅列在天上的群星，分佈在棋盤上的棋子。形容事物眾多而分散排列。羅，排列；布，分佈。", "missingFormat": "星羅棋(？)", "options": ["布", "逼", "籟", "壯"], "answer": "布", "sentence": "表哥潛進深海裏，欣賞海底（＿＿＿＿）的珊瑚和魚兒。", "sentence2": "從高處俯瞰，下面的房屋變成了一塊塊小積木嵌在土地上，猶如（＿＿＿＿）。"},
  {"id": "chi_009", "unit": "成語一", "word": "破瓦頹垣", "meaning": "指屋瓦破損，牆垣倒塌。形容破敗荒涼的景象。頹，倒塌。垣，矮牆。", "missingFormat": "破瓦頹(？)", "options": ["垣", "發", "鑼", "鼎"], "answer": "垣", "sentence": "地震過後，這一帶盡是（＿＿＿＿），不少居民因而流離失所。", "sentence2": "去年這兒還有一幢幢雄偉宏偉的高樓，如今卻只留下（＿＿＿＿）。"},
  {"id": "chi_010", "unit": "成語一", "word": "氣象萬千", "meaning": "形容景象千變萬化，極為壯觀。", "missingFormat": "氣象萬(？)", "options": ["千", "真", "模", "地"], "answer": "千", "sentence": "這個新都市發展迅速，一派（＿＿＿＿）的景象。", "sentence2": "雲霧繞着山峯不斷變化，景色（＿＿＿＿），令人神往。"},
  {"id": "chi_011", "unit": "成語一", "word": "琳琅滿目", "meaning": "形容滿眼所見都是美好而珍貴的東西。琳瑯，精美的玉石。", "missingFormat": "琳琅滿(？)", "options": ["目", "色", "引", "鑼"], "answer": "目", "sentence": "這家博物館的展品（＿＿＿＿），吸引了不少人於假日前來參觀。", "sentence2": "哥哥打算在這些（＿＿＿＿）的商品中，選購一份送給媽媽作為生日禮物。"},
  {"id": "chi_012", "unit": "成語一", "word": "煥然一新", "meaning": "形容散發光彩，呈現出新的面貌。煥然，鮮明、光亮。", "missingFormat": "煥然一(？)", "options": ["新", "麗", "一", "兢"], "answer": "新", "sentence": "表哥到外國讀書後，改變了衣着和打扮，整個人（＿＿＿＿）。", "sentence2": "這家咖啡店經過裝修後，風格變得簡約清新，給人（＿＿＿＿）的感覺。"},
  {"id": "chi_013", "unit": "成語一", "word": "萬籟俱寂", "meaning": "形容萬物無聲，一片寂靜。萬籟，自然界的各種聲音。", "missingFormat": "萬籟俱(？)", "options": ["寂", "劍", "奪", "煙"], "answer": "寂", "sentence": "山林中（＿＿＿＿），彷彿萬物都沉睡了。", "sentence2": "在這（＿＿＿＿）的環境下，我放輕腳步走路，以免破壞寧靜的氣氛。"},
  {"id": "chi_014", "unit": "成語一", "word": "歷歷在目", "meaning": "清楚明白地出現在眼前。歷歷，清楚分明。", "missingFormat": "歷歷在(？)", "options": ["目", "移", "鼎", "土"], "answer": "目", "sentence": "我們用望遠鏡從太平洋山頂眺望，遠處的景物全都（＿＿＿＿）。", "sentence2": "堂弟不經不覺八歲了，他嬰兒時的模樣，至今仍然（＿＿＿＿）。"},
  {"id": "chi_015", "unit": "成語一", "word": "鑼鼓喧天", "meaning": "本指鑼鼓聲音大得震天。現形容氣氛非常熱鬧，景象歡樂喜慶。", "missingFormat": "鑼鼓喧(？)", "options": ["天", "抹", "外", "朵"], "answer": "天", "sentence": "龍舟比賽進行期間，城門河上（＿＿＿＿），非常熱鬧。", "sentence2": "購物商場開幕時，請來了舞獅助興，（＿＿＿＿）的盛況吸引了大批顧客。"},
  {"id": "chi_016", "unit": "成語二", "word": "大快朵頤", "meaning": "飽食、愉快的樣子。朵，動。頤，下巴。朵頤，動着腮頰進食。", "missingFormat": "大快朵(？)", "options": ["頤", "鼓", "緻", "長"], "answer": "頤", "sentence": "這條街道上美食店林立，總有一家能讓你（＿＿＿＿）！", "sentence2": "爸爸媽媽帶柏軒到餐館（＿＿＿＿）了一番，令他感到非常滿足。"},
  {"id": "chi_017", "unit": "成語二", "word": "口若懸河", "meaning": "說起話來像河水傾瀉一樣，說個不停。形容能言善辯。", "missingFormat": "口若懸(？)", "options": ["河", "朽", "滿", "緘"], "answer": "河", "sentence": "惠萍發表意見時（＿＿＿＿），期望得到大家的認同。", "sentence2": "售貨員（＿＿＿＿）地推銷產品，吸引了很多顧客爭相購買。"},
  {"id": "chi_018", "unit": "成語二", "word": "口蜜腹劍", "meaning": "口中有蜜，肚子裏卻藏着劍。形容人把話說得動聽，事實上內心險惡，處處想陷害別人。", "missingFormat": "口蜜腹(？)", "options": ["劍", "迷", "杳", "啃"], "answer": "劍", "sentence": "他這個人（＿＿＿＿），嘴上說着好聽的話，心裏卻盤算着壞主意。", "sentence2": "騙徒大多是（＿＿＿＿）的人，利用虛假動聽的話騙取別人的錢財。"},
  {"id": "chi_019", "unit": "成語二", "word": "三緘其口", "meaning": "嘴巴加了三道封條。形容說話小心謹慎或不說話。緘，封住、緊閉。", "missingFormat": "三緘其(？)", "options": ["口", "外", "體", "給"], "answer": "口", "sentence": "關於芷晴退學的原因，老師們都（＿＿＿＿），沒有透露半句。", "sentence2": "你不知道事情的經過，就應該（＿＿＿＿），不要隨便發表意見。"},
  {"id": "chi_020", "unit": "成語二", "word": "不亢不卑", "meaning": "表示對別人的態度合宜，既傲慢自大，也不低聲下氣。亢，高傲。", "missingFormat": "不亢不(？)", "options": ["卑", "水", "源", "腹"], "answer": "卑", "sentence": "這個人在公開場合的言行舉止（＿＿＿＿），真有教養！", "sentence2": "我要養成（＿＿＿＿）的處事態度，提升待人接物的技巧。"},
  {"id": "chi_021", "unit": "成語二", "word": "自吹自擂", "meaning": "自己吹喇叭，自己打鼓。比喻自我吹噓。擂，打鼓。", "missingFormat": "自吹自(？)", "options": ["擂", "喧", "源", "探"], "answer": "擂", "sentence": "他（＿＿＿＿）的舉動令人反感，其他人都不愛跟他交往。", "sentence2": "健常在別人面前（＿＿＿＿），其實他並沒有甚麼真才實學。"},
  {"id": "chi_022", "unit": "成語二", "word": "呆若木雞", "meaning": "形容愚笨或受驚嚇而發呆的樣子。", "missingFormat": "呆若木(？)", "options": ["雞", "籟", "在", "信"], "answer": "雞", "sentence": "玉儀上課時（＿＿＿＿）地看着天花板，所以被老師責罵。", "sentence2": "看到不擅廚藝的媽媽又在廚房創作新菜式，姐姐（＿＿＿＿），不知如何是好。"},
  {"id": "chi_023", "unit": "成語二", "word": "虎視眈眈", "meaning": "指像老虎般用威嚇的眼神盯着人，比喻人心裏存着不良的意圖，貪婪地注視着，等待機會搶奪。眈眈，注視的樣子。", "missingFormat": "虎視眈(？)", "options": ["眈", "自", "鼓", "璨"], "answer": "眈", "sentence": "花貓（＿＿＿＿）地盯着洞口的老鼠，想要一把捉住牠。", "sentence2": "貪吃的弟弟一直對我手上的這盒餅乾（＿＿＿＿），恨不得想要把它搶去。"},
  {"id": "chi_024", "unit": "成語二", "word": "拐彎抹角", "meaning": "比喻說話或做事繞圈子，不直接。", "missingFormat": "拐彎抹(？)", "options": ["角", "撒", "規", "木"], "answer": "角", "sentence": "請你不要再（＿＿＿＿）了，有甚麼事就直接告訴我吧！", "sentence2": "麗欣說話從不（＿＿＿＿），因此大家都特別喜歡跟她聊天。"},
  {"id": "chi_025", "unit": "成語二", "word": "神魂顛倒", "meaning": "形容對某人或某事物非常着迷，以致心神不定，失去常態。", "missingFormat": "神魂顛(？)", "options": ["倒", "土", "專", "爾"], "answer": "倒", "sentence": "時下不少青年人（＿＿＿＿）地追捧偶像，甚至為了「追星」而做出很多瘋狂行為。", "sentence2": "俊希最近被一款新推出的電子遊戲弄得（＿＿＿＿），難怪學業成績一落千丈。"},
  {"id": "chi_026", "unit": "成語二", "word": "規行矩步", "meaning": "指嚴格地按照規矩辦事，毫不敷衍。比喻做事刻板，不知變通。規、矩，分別指圓規和角尺，代指規定、準則。", "missingFormat": "規行矩(？)", "options": ["步", "萬", "專", "奪"], "answer": "步", "sentence": "叔叔是個（＿＿＿＿）的人，做事謹慎，因而深得上司欣賞。", "sentence2": "你做事過於（＿＿＿＿）了，並不適合這項講求創新思維的工作。"},
  {"id": "chi_027", "unit": "成語二", "word": "理直氣壯", "meaning": "表示因理據充分，說話充滿氣勢，無所畏懼。", "missingFormat": "理直氣(？)", "options": ["壯", "爾", "在", "暇"], "answer": "壯", "sentence": "我還沒見過有人可以把謊話說得這麼（＿＿＿＿）呢！", "sentence2": "只要你的觀點合理，就不妨（＿＿＿＿）地向大家說出你的想法。"},
  {"id": "chi_028", "unit": "成語二", "word": "戰戰兢兢", "meaning": "因害怕而發抖。形容十分害怕或小心謹慎的樣子。", "missingFormat": "戰戰兢(？)", "options": ["兢", "雌", "業", "見"], "answer": "兢", "sentence": "他在校長面前露出副（＿＿＿＿）的樣子。", "sentence2": "這是志恒初次公開演講，所以表現得（＿＿＿＿）。"},
  {"id": "chi_029", "unit": "成語二", "word": "信口雌黃", "meaning": "比喻不顧事實，隨口亂說或隨意批評。雌黃，一種可用作原料的黃色礦物，古人用來塗改寫錯的字，作用類似現時的塗改液。", "missingFormat": "信口雌(？)", "options": ["黃", "迷", "泄", "通"], "answer": "黃", "sentence": "樂賢從不（＿＿＿＿），他說的話一定是有事實根據的。", "sentence2": "你還沒弄清真相，怎麼就在這兒（＿＿＿＿），胡亂指控別人呢？"},
  {"id": "chi_030", "unit": "成語二", "word": "顧影自憐", "meaning": "形容人孤獨失意，亦可形容自我欣賞的樣子。顧，回頭看。", "missingFormat": "顧影自(？)", "options": ["憐", "視", "頹", "戰"], "answer": "憐", "sentence": "她想到親人已經先後離世，不免（＿＿＿＿）起來。", "sentence2": "大家都認為他表現不理想，他卻繼續（＿＿＿＿）。"},
  {"id": "chi_031", "unit": "字詞一", "word": "規模", "meaning": "指事業、工程、機構等所包含的範圍或具備的格局。", "missingFormat": "規(？)", "options": ["模", "腹", "歷", "卧"], "answer": "模", "sentence": "這間新開幕的圖書館（＿＿）宏大，藏書超過百萬冊。", "sentence2": "為了應付日益增加的訂單，工廠決定擴大生產（＿＿）。"},
  {"id": "chi_032", "unit": "字詞一", "word": "完善", "meaning": "完備美好；沒有缺點。", "missingFormat": "完(？)", "options": ["善", "萬", "獨", "吹"], "answer": "善", "sentence": "這座社區的公共設施非常（＿＿），居民生活十分便利。", "sentence2": "我們需要建立一套（＿＿）的制度，才能有效管理這些資料。"},
  {"id": "chi_033", "unit": "字詞一", "word": "遜色", "meaning": "比不上；差勁。", "missingFormat": "遜(？)", "options": ["色", "直", "河", "亢"], "answer": "色", "sentence": "雖然這部電影的預算不高，但特效和劇情卻一點也不（＿＿）。", "sentence2": "他的畫作與大師的作品相比，仍然顯得有些（＿＿）。"},
  {"id": "chi_034", "unit": "字詞一", "word": "逼真", "meaning": "極像真的；非常相像。", "missingFormat": "逼(？)", "options": ["真", "河", "戰", "人"], "answer": "真", "sentence": "這個洋娃娃做得十分（＿＿），就像一個真正的嬰兒。", "sentence2": "他在電影中飾演的反派角色十分（＿＿），令人不寒而慄。"},
  {"id": "chi_035", "unit": "字詞一", "word": "引人注目", "meaning": "引起人們的注意或視線。", "missingFormat": "引人注(？)", "options": ["目", "生", "吹", "沸"], "answer": "目", "sentence": "她在晚宴上穿了一件鮮紅色的禮服，十分（＿＿＿＿）。", "sentence2": "這座造型奇特的建築物，成為城市中最（＿＿＿＿）的地標。"},
  {"id": "chi_036", "unit": "字詞一", "word": "探究", "meaning": "探索研究；探尋追究。", "missingFormat": "探(？)", "options": ["究", "直", "惑", "角"], "answer": "究", "sentence": "科學家們不斷（＿＿）宇宙的奧秘，希望能解開生命的起源。", "sentence2": "這篇文章深入（＿＿）了社會不平等現象的根源。"},
  {"id": "chi_037", "unit": "字詞一", "word": "體驗", "meaning": "親身經歷；通過實踐來認識周圍的事物。", "missingFormat": "體(？)", "options": ["驗", "然", "專", "千"], "answer": "驗", "sentence": "這次露營活動讓我（＿＿）了野外生活的樂趣。", "sentence2": "他決定親身（＿＿）一下當地人的生活方式。"},
  {"id": "chi_038", "unit": "字詞一", "word": "百聞不如一見", "meaning": "聽得再多，也不如親眼見到一次。", "missingFormat": "百聞不如一(？)", "options": ["見", "鼎", "迷", "業"], "answer": "見", "sentence": "大家都說這裡的風景很美，今天親眼看到，果然是（＿＿＿＿＿＿）。", "sentence2": "這項新技術到底有多神奇，真是（＿＿＿＿＿＿）。"},
  {"id": "chi_039", "unit": "字詞三", "word": "偶爾", "meaning": "間或；有時候。", "missingFormat": "偶(？)", "options": ["爾", "累", "三", "眈"], "answer": "爾", "sentence": "他平時工作很忙，（＿＿）才會和朋友聚餐。", "sentence2": "這條路上（＿＿）會有車輛經過，所以還是要小心。"},
  {"id": "chi_040", "unit": "字詞三", "word": "耀眼", "meaning": "光線強烈，使人眼花。", "missingFormat": "耀(？)", "options": ["眼", "虎", "三", "遜"], "answer": "眼", "sentence": "夏日的陽光十分（＿＿），出門要記得戴太陽眼鏡。", "sentence2": "她在舞台上的表現十分（＿＿），贏得了觀眾的熱烈掌聲。"},
  {"id": "chi_041", "unit": "字詞三", "word": "反射", "meaning": "光線、聲波等遇到障礙物折回。", "missingFormat": "反(？)", "options": ["射", "生", "角", "黃"], "answer": "射", "sentence": "鏡子能（＿＿）光線，所以我們能在鏡子裡看到自己。", "sentence2": "這座建築物的玻璃幕牆（＿＿）出耀眼的陽光。"},
  {"id": "chi_042", "unit": "字詞三", "word": "撒", "meaning": "散佈；拋棄。", "missingFormat": "(？)", "options": ["撒", "步", "無", "細"], "answer": "撒", "sentence": "他在農田裡（＿）下種子，期待秋天能有好收成。", "sentence2": "小女孩把花瓣（＿）在紅毯上，迎接新娘的到來。"},
  {"id": "chi_043", "unit": "字詞三", "word": "奪目", "meaning": "光彩耀眼，引人注目。", "missingFormat": "奪(？)", "options": ["目", "兢", "三", "劍"], "answer": "目", "sentence": "這顆鑽石光彩（＿＿），價值連城。", "sentence2": "她的笑容燦爛（＿＿），感染了周圍的人。"},
  {"id": "chi_044", "unit": "字詞三", "word": "猶如", "meaning": "如同；好像。", "missingFormat": "猶(？)", "options": ["如", "偶", "沸", "煥"], "answer": "如", "sentence": "時間（＿＿）流水，一去不復返。", "sentence2": "這片美麗的風景（＿＿）一幅畫，讓人流連忘返。"},
  {"id": "chi_045", "unit": "字詞三", "word": "卧", "meaning": "躺下；趴伏。", "missingFormat": "(？)", "options": ["卧", "喧", "給", "亢"], "answer": "卧", "sentence": "他生病了，只好（＿）床休息。", "sentence2": "一隻小狗（＿）在門口，安靜地睡著了。"},
  {"id": "chi_046", "unit": "字詞三", "word": "璀璨", "meaning": "形容光彩奪目。", "missingFormat": "璀(？)", "options": ["璨", "直", "捕", "虎"], "answer": "璨", "sentence": "夜空中的繁星（＿＿），美麗極了。", "sentence2": "這座城市在夜晚燈火（＿＿），充滿了活力。"},
  {"id": "chi_047", "unit": "字詞五", "word": "繁衍", "meaning": "繁殖衍生；逐漸增多。", "missingFormat": "繁(？)", "options": ["衍", "日", "聲", "真"], "answer": "衍", "sentence": "這些動植物在這個島嶼上（＿＿）了數千年。", "sentence2": "人類在地球上（＿＿）後代，創造了燦爛的文明。"},
  {"id": "chi_048", "unit": "字詞五", "word": "土生土長", "meaning": "從小在當地生長。", "missingFormat": "土生土(？)", "options": ["長", "羅", "璨", "落"], "answer": "長", "sentence": "他是一個（＿＿＿＿）的香港人，對這裡的一切都非常熟悉。", "sentence2": "這些（＿＿＿＿）的農產品，品質優良，深受消費者喜愛。"},
  {"id": "chi_049", "unit": "字詞五", "word": "辨認", "meaning": "根據特點辨別，做出判斷。", "missingFormat": "辨(？)", "options": ["認", "聞", "善", "外"], "answer": "認", "sentence": "這對雙胞胎長得太像了，很難（＿＿）誰是哥哥、誰是弟弟。", "sentence2": "他在人群中一眼就（＿＿）出了自己的朋友。"},
  {"id": "chi_050", "unit": "字詞五", "word": "爆發", "meaning": "火山內部岩漿突然衝破地殼，向四外迸出。比喻力量、情緒等忽然發作，或事變突然發生。", "missingFormat": "爆(？)", "options": ["發", "水", "獨", "拐"], "answer": "發", "sentence": "這座火山突然（＿＿），噴出大量的火山灰和岩漿。", "sentence2": "群眾的憤怒終於（＿＿）了，引發了大規模的抗議活動。"},
  {"id": "chi_051", "unit": "字詞五", "word": "落地生根", "meaning": "比喻長期在一個地方居住下來。", "missingFormat": "落地生(？)", "options": ["根", "見", "快", "腐"], "answer": "根", "sentence": "他們一家人來到這個陌生的城市，經過多年的努力，終於（＿＿＿＿）。", "sentence2": "這項新政策希望能讓更多人才在這裡（＿＿＿＿）。"},
  {"id": "chi_052", "unit": "字詞五", "word": "遷移", "meaning": "離開原來的地方，到別的地方去。", "missingFormat": "遷(？)", "options": ["移", "神", "大", "聞"], "answer": "移", "sentence": "由於氣候變遷，許多動物被迫（＿＿）到新的棲息地。", "sentence2": "我們家下個月就要（＿＿）到另一個城市了。"},
  {"id": "chi_053", "unit": "字詞五", "word": "相映成趣", "meaning": "相互襯托，顯得很有趣味。", "missingFormat": "相映成(？)", "options": ["趣", "獵", "劍", "大"], "answer": "趣", "sentence": "湖水與周圍的山色（＿＿＿＿），構成了一幅美麗的風景畫。", "sentence2": "這兩件藝術品擺在一起，（＿＿＿＿），更顯其獨特之處。"},
  {"id": "chi_054", "unit": "字詞五", "word": "得天獨厚", "meaning": "具備的條件特別優越，所處環境特別好。", "missingFormat": "得天獨(？)", "options": ["厚", "頤", "籟", "給"], "answer": "厚", "sentence": "這個國家擁有（＿＿＿＿）的自然資源，發展潛力巨大。", "sentence2": "他（＿＿＿＿），擁有極高的音樂天賦。"},
  {"id": "chi_055", "unit": "字詞六", "word": "偽裝", "meaning": "假裝；用以欺騙別人產生假象的裝扮。", "missingFormat": "偽(？)", "options": ["裝", "千", "遜", "俱"], "answer": "裝", "sentence": "這隻昆蟲的（＿＿）技巧非常高超，很難被天敵發現。", "sentence2": "他（＿＿）成一個商人，混進了敵人的內部。"},
  {"id": "chi_056", "unit": "字詞六", "word": "腐朽", "meaning": "木料等含有水分，經過長時期而被蟲蛀或微生物破壞。比喻思想陳舊、沒落。", "missingFormat": "腐(？)", "options": ["朽", "璀", "抹", "桃"], "answer": "朽", "sentence": "這根木頭已經（＿＿）了，不能再用來蓋房子。", "sentence2": "我們必須摒棄這些（＿＿）的思想，才能不斷進步。"},
  {"id": "chi_057", "unit": "字詞六", "word": "迷惑", "meaning": "使人迷亂；辨不清是非。", "missingFormat": "迷(？)", "options": ["惑", "生", "世", "象"], "answer": "惑", "sentence": "敵人的花言巧語（＿＿）了他，讓他做出了錯誤的判斷。", "sentence2": "這道數學題太難了，讓他感到十分（＿＿）。"},
  {"id": "chi_058", "unit": "字詞六", "word": "捕獵", "meaning": "捕捉、獵取（動物）。", "missingFormat": "捕(？)", "options": ["獵", "偽", "彎", "趣"], "answer": "獵", "sentence": "原始人以（＿＿）野生動物為生。", "sentence2": "為了保護生態平衡，政府禁止非法（＿＿）野生動物。"},
  {"id": "chi_059", "unit": "字詞六", "word": "細緻", "meaning": "精細周密。", "missingFormat": "細(？)", "options": ["緻", "鑼", "撒", "奪"], "answer": "緻", "sentence": "這件藝術品的雕刻非常（＿＿），令人嘆為觀止。", "sentence2": "他做事非常（＿＿），從不放過任何一個細節。"},
  {"id": "chi_060", "unit": "字詞六", "word": "啃", "meaning": "一點兒一點兒地咬下來。", "missingFormat": "(？)", "options": ["啃", "引", "木", "羅"], "answer": "啃", "sentence": "這隻小狗正在（＿）一根骨頭。", "sentence2": "他遇到難題時，總是喜歡（＿）指甲。"},
  {"id": "chi_061", "unit": "字詞六", "word": "專業", "meaning": "專門的學業。指主要從事某種工作或職業。", "missingFormat": "專(？)", "options": ["業", "卧", "煥", "體"], "answer": "業", "sentence": "他在大學裡主修計算機科學（＿＿）。", "sentence2": "這家公司提供（＿＿）的法律諮詢服務。"},
  {"id": "chi_062", "unit": "字詞六", "word": "斑斕", "meaning": "色彩錯雜燦爛的樣子。", "missingFormat": "斑(？)", "options": ["斕", "萬", "兢", "破"], "answer": "斕", "sentence": "秋天的樹葉色彩（＿＿），美麗極了。", "sentence2": "這隻蝴蝶的翅膀上有著（＿＿）的圖案。"}
];

/**
* 智慧型題目轉換器 (支援：1.字義配字 / 2.例句一填充 / 3.例句二填充)
* @param {Object} rawQ 原始字詞物件
* @param {String} forceMode 'mixed' | 'sentence' | 'meaning'
*/
export function normalizeQuestion(rawQ, forceMode = 'mixed') {
  let mode = 'meaning';
  if (forceMode === 'sentence') {
      mode = Math.random() < 0.5 ? 's1' : 's2';
  } else if (forceMode === 'mixed') {
      const r = Math.random();
      if (r < 0.34) mode = 'meaning';
      else if (r < 0.67) mode = 's1';
      else mode = 's2';
  }

  // 若選擇例句填充模式 (s1 或 s2)，動態生成 4 個完整詞語選項
  if ((mode === 's1' || mode === 's2') && rawQ.sentence) {
      const sentText = (mode === 's2' && rawQ.sentence2) ? rawQ.sentence2 : rawQ.sentence;
      const label = (mode === 's2' && rawQ.sentence2) ? '例句填充 (二)' : '例句填充 (一)';

      // 優先從同一課節抽取 3 個干擾詞語
      let sameUnitPool = QuestionBank.filter(q => q.unit === rawQ.unit && q.word !== rawQ.word).map(q => q.word);
      if (sameUnitPool.length < 3) {
          sameUnitPool = QuestionBank.filter(q => q.word !== rawQ.word).map(q => q.word);
      }
      const distractors = sameUnitPool.sort(() => Math.random() - 0.5).slice(0, 3);
      const wordOptions = [rawQ.word, ...distractors].sort(() => Math.random() - 0.5);

      // 語音朗讀時將（＿＿＿＿）讀作「某詞語」，避免直接劇透答案
      const spokenSentence = sentText.replace(/（＿+）/g, '，某詞語，');

      return {
          id: rawQ.id,
          subject: 'chi',
          unit: rawQ.unit,
          modeLabel: `📝 ${label}`,
          prompt: `請選出最適合填入句中的詞語：\n「${sentText}」`,
          ttsText: `請選出適合填入句中的詞語：${spokenSentence}`,
          options: wordOptions,
          answer: rawQ.word,
          difficulty: 1
      };
  }

  // 字義配字模式 (預設)
  const shuffledOpts = [...rawQ.options].sort(() => Math.random() - 0.5);
  return {
      id: rawQ.id,
      subject: 'chi',
      unit: rawQ.unit,
      modeLabel: '🔤 字義配字',
      prompt: `【${rawQ.missingFormat}】—— ${rawQ.meaning}`,
      ttsText: `${rawQ.word}。意思係：${rawQ.meaning}`,
      options: shuffledOpts,
      answer: rawQ.answer,
      difficulty: 1
  };
}